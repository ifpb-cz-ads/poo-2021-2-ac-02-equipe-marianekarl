class BMExercicio03 {
 public class void main(string[] args) {
        double queijo1 = 2.95;
        double queijo2 = 3.50;
        double resultadoadicional = queijo1 + queijo2;
        
        final double valor = 0.0825; // 8.25%
        
        double valorcalculado = (adição * valor) + adição;
        
        double novoresultado = (queijo1 * valor) + (queijo2 * taxa);
        
        boolean muitoCaro = novoresultado = 10; 
        
        System.out.println(" O queijo1  vale " + queijo1 + "e o queijo2 vale " + queijo2);
        System.out.println("O resultado dos queijos vale igual a " + resultadoadicional);
        System.out.println("a soma dos queijos com o valor e igual a " + valorcalculado);
        System.out.println(("O queijo1 custa com o valor " +(queijo1 * valor) + queijo1) + "e o queijo2 resulta com o valor " + ((queijo2 * valor) + queijo2)); 
        System.out.println ("Retornou " + altopreço);
        
    }
}